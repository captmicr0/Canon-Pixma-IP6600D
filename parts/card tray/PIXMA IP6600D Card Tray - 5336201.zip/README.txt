PIXMA IP6600D Card Tray by KunoMaker on Thingiverse: https://www.thingiverse.com/thing:5336201

Summary:
This printer tray can be used for imprinting plastic cards 85.6 mm x 54 mm